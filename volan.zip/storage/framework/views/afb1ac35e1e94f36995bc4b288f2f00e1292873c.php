<script src="https://js.pusher.com/7.2/pusher.min.js"></script>
<div class="row">
    <div class="col-md-4">
        <div class="card">
            <h5 class="card-header"><i class="mdi mdi-information-outline me-1"></i>Informasi</h5>
            <div class="card-body p-0" style="margin-bottom: -16px;">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <tr>
                            <td>
                                <span class="fw-bold"><?php echo e($ticket); ?></span><br>
                                Order
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <span class="fw-bold">Tipe</span><br>
                                Pesanan
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <span class="fw-bold">Status</span><br>
                                <span class="btn btn-soft-success btn-sm font-size-13">Open</span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <span class="fw-bold">Pembaruan Terakhir</span><br>
                                2 hari yang lalu
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <a href="https://gudangjasa.com/ticket/list"
                    class="btn btn-primary btn-sm waves-effect waves-light float-end"><i
                        class="mdi mdi-arrow-left-circle-outline me-1"></i>Kembali</a>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <section class="msger">
            <header class="msger-header">
                <div class="msger-header-title">
                    <i class="fas fa-comment-alt"></i> Customer Service
                </div>
                <div class="msger-header-options">
                    <span><i class="fas fa-cog"></i></span>
                </div>
            </header>

            <main class="msger-chat">
                <div class="msg left-msg">
                    <div class="msg-img" style="background-image: url(<?php echo e(URL::asset('assets/images/avtar-2.png')); ?>)">
                    </div>

                    <div class="msg-bubble">
                        <div class="msg-info">
                            <div class="msg-info-name">BOT</div>
                            <div class="msg-info-time">12:45</div>
                        </div>

                        <div class="msg-text">
                            Hi, welcome to <?php echo e(env('TEXT_SMALL')); ?>! Silahkan sampaikan keluhan anda
                        </div>
                    </div>
                </div>
                <div class="msg right-msg mt-3">
                    <div class="msg-img" style="background-image: url(<?php echo e(URL::asset('assets/images/users.png')); ?>)">
                    </div>

                    <div class="msg-bubble">
                        <div class="msg-info">
                            <div class="msg-info-name">Sajad</div>
                            <div class="msg-info-time">12:46</div>
                        </div>

                        <div class="msg-text">
                            You can change your name in JS section!
                        </div>
                    </div>
                </div>
            </main>

            <form class="msger-inputarea">
                <input type="text" class="msger-input" placeholder="Enter your message...">
                <button type="submit" class="msger-send-btn">Send</button>

            </form>
        </section>
    </div>

</div>
<script>
    $(document).ready(function() {
        // var pusher = new Pusher('<?php echo e(env('PUSHER_APP_KEY')); ?>', {
        //     cluster: 'ap1'
        // });
        // var channel = pusher.subscribe('chat');
        // channel.bind('chat-event', function(data) {
        // });
    });
</script><?php /**PATH C:\xampp\htdocs\laravel\smm\resources\views/livewire/chat-ticket.blade.php ENDPATH**/ ?>