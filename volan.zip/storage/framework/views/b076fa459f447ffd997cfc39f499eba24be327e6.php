<?php

function tanggal($tanggal)
{
$bulan = array(
1 => 'Januari',
'Februari',
'Maret',
'April',
'Mei',
'Juni',
'Juli',
'Agustus',
'September',
'Oktober',
'November',
'Desember'
);
$pecahkan = explode('-', $tanggal);

// variabel pecahkan 0 = tanggal
// variabel pecahkan 1 = bulan
// variabel pecahkan 2 = tahun

return $pecahkan[2] . ' ' . $bulan[(int)$pecahkan[1]] . ' ' . $pecahkan[0];
}
?>

<div class="row">
    <div class="col-md-12">
        <div class="btn-group flex-wrap mb-3">
            <button wire:click="all" class="btn btn-primary active">Semua</button>
            <button wire:click="active" class="btn btn-primary ">Verify</button>
            <button wire:click="notverify" class="btn btn-primary ">Not Verify</button>
        </div>
    </div>
</div>
<div class="card">
    <h5 class="card-header"><i class="mdi mdi-history me-1"></i>User Table</h5>
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Tampilkan</span>
                    </div>
                    <select wire:model="perPage" class="form-control" name="row" id="table-row">
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    <div class="input-group-append">
                        <span class="input-group-text">baris.</span>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
            </div>
            <div class="col-md-3">
                <div class="input-group mb-3">
                    <input type="text" wire:model.debounce.300ms="search" class="form-control" name="search"
                        id="table-search" value="" placeholder="Cari...">
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Balance</th>
                        <th>Omzet</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($row->name); ?></td>
                        <td><?php echo e($row->username); ?></td>
                        <td><?php echo e($row->email); ?></td>
                        <td><?php echo e($row->balance); ?></td>
                        <td><?php echo e($row->omzet); ?></td>
                        <td><?php echo e(Str::ucfirst($row->role)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel\smm\resources\views/livewire/admin/users-table.blade.php ENDPATH**/ ?>