<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('favorit-table', [])->html();
} elseif ($_instance->childHasBeenRendered('nctE0XJ')) {
    $componentId = $_instance->getRenderedChildComponentId('nctE0XJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('nctE0XJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nctE0XJ');
} else {
    $response = \Livewire\Livewire::mount('favorit-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('nctE0XJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\volan\resources\views/order/layanan-favorit.blade.php ENDPATH**/ ?>