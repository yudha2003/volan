<div wire:loading class="mt-2">
    <div class="loader ease-linear rounded-full border-2 border-t-2 border-slate-200 h-6 w-6"></div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\smm\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/frameworks/tailwind/header/loading.blade.php ENDPATH**/ ?>