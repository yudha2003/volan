<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.refill-table', [])->html();
} elseif ($_instance->childHasBeenRendered('6hBer7J')) {
    $componentId = $_instance->getRenderedChildComponentId('6hBer7J');
    $componentTag = $_instance->getRenderedChildComponentTagName('6hBer7J');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6hBer7J');
} else {
    $response = \Livewire\Livewire::mount('admin.refill-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('6hBer7J', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starsos1/laravel/resources/views/admin/refill.blade.php ENDPATH**/ ?>