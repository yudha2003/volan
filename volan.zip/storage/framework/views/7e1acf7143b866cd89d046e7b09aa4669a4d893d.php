<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo e(env('TITLE_WEB')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta
        content="GUDANGJASA adalah Panel Utama Terbaik di Indonesia. Layanan Termurah, Bergaransi. Dan Terbesar Yang Menyediyakan Berbagai Macam Layanan Platfrom Sosial Media Marketing."
        name="description" />
    <meta
        content="GudangJasa, smm indonesia, smm panel indonesia, smm panel termurah, smm panel indonesia termurah, smm panel terbaik, smm panel indonesia terbaik, smm panel terlengkap, panel smm terbaik, smm panel indonesia terlengkap, smm panel terpercaya, smm panel indonesia terpercaya, smm panel termurah di indonesia, smm panel shopee, smm panel tokopedia, followers tokopedia murah, panel instagram, smm panel, followers shopee, followers shopee murah, jasa followers instagram, cara menambah followers instagram, followers instagram gratis, jasa followers tokopedia, jasa followers shopee, jasa followers instagram, panel smm, followers gratis, followers instagram, followers indonesia"
        name="keyword" />
    <meta content="AG MEDIA DIGITAL" name="author" />
    <link rel="shortcut icon" href="<?php echo e(env('URL_LOGO')); ?>">
    <link href="<?php echo e(url('/')); ?>/assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('/')); ?>/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('/')); ?>/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('/')); ?>/assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
        integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css"
        integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="<?php echo e(url('/')); ?>/assets/libs/jquery/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"
        integrity="sha512-Tn2m0TIpgVyTzzvmxLNuqbSJH3JP8jm+Cy3hvHrW7ndTDcJ1w5mBiksqDBb8GpE2ksktFvDB/ykZ0mDpsZj20w=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body data-topbar="light" data-layout="horizontal">
    <div id="layout-wrapper">
        <header id="page-topbar">
            <div class="navbar-header">
                <div class="d-flex">
                    <div class="navbar-brand-box text-center d-none d-lg-block">
                        <a href="javascript:;" class="logo logo-dark">
                            <span class="logo-lg">
                                <span style="font-weight: 1000; font-size: 20px;"><?php echo e(env('TEXT_LARGE')); ?></span>
                            </span>
                        </a>
                        <a href="javascript:;" class="logo logo-light">
                            <span class="logo-lg">
                                <span style="font-weight: 1000; font-size: 20px;"><?php echo e(env('TEXT_SMALL')); ?></span>
                            </span>
                        </a>
                    </div>
                    <button type="button" class="btn btn-sm px-3 font-size-24 d-lg-none header-item"
                        data-bs-toggle="collapse" data-bs-target="#topnav-menu-content">
                        <i class="ri-menu-2-line align-middle"></i>
                    </button>
                </div>
                <div class="d-flex">
                    <div class="dropdown d-inline-block user-dropdown">
                        <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="d-block d-xl-none rounded-circle header-profile-user"
                                src="../assets/images/user.png" alt="Header Avatar">
                            <img class="d-none d-xl-inline-block rounded-circle header-profile-user"
                                style="margin-top: -23px;" src="../assets/images/user.png" alt="Header Avatar">
                            <span class="d-none d-xl-inline-block me-1"></span>
                            <span class="d-none d-xl-inline-block ms-1"
                                style="margin-top: 1px;"><?php echo e(Auth::user()->name); ?><br><small>Rp.
                                    <?php echo e(number_format(Auth::user()->balance, 0, ',', '.')); ?></small></span>
                            <span class="d-none d-xl-inline-block me-1"></span>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end">
                            <a class="dropdown-item" href="<?php echo e(url('/')); ?>/security"><i
                                    class="mdi mdi-shield-account align-middle me-1"></i> Keamanan</a>
                            <a class="dropdown-item d-block" href="<?php echo e(url('/')); ?>/settings"><i
                                    class="mdi mdi-cog align-middle me-1"></i> Pengaturan</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-danger" href="javascript:;" onclick="confirm_logout();"><i
                                    class="mdi mdi-power align-middle me-1 text-danger"></i> Keluar</a>
                        </div>
                    </div>

                    <div class="dropdown d-inline-block">
                        <button type="button" class="btn header-item noti-icon right-bar-toggle waves-effect">
                            <i class="mdi mdi-cog"></i>
                        </button>
                    </div>

                </div>
            </div>
        </header>
        <div class="topnav">
            <div class="container-fluid">
                <nav class="navbar navbar-light navbar-expand-lg topnav-menu">
                    <div class="collapse navbar-collapse" id="topnav-menu-content">
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown active">
                                <a class="nav-link" href="<?php echo e(url('/')); ?>/"><i
                                        class="mdi mdi-home-variant-outline me-2"></i>Dashboard</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(url('/')); ?>/page/hof"><i
                                        class="mdi mdi-trophy-outline me-2"></i>Top 10</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle arrow-none" href="javascript:;"
                                    data-bs-toggle="dropdown" role="button"><i
                                        class="mdi mdi-cart-arrow-up me-2"></i>Sosial Media<div class="arrow-down">
                                    </div></a>
                                <div class="dropdown-menu">
                                    <a href="<?php echo e(url('/')); ?>/order/single" class="dropdown-item">Pesan Baru</a>
                                    <a href="<?php echo e(url('/')); ?>/order/massal" class="dropdown-item">Pesan Massal</a>
                                    <a href="<?php echo e(url('/')); ?>/order/history" class="dropdown-item">Riwayat
                                        Pesanan</a>
                                    <a href="<?php echo e(url('/')); ?>/order/refill" class="dropdown-item">Riwayat
                                        Refill</a>
                                    <a href="<?php echo e(url('/')); ?>/page/services" class="dropdown-item">Daftar
                                        Layanan</a>
                                    <a href="<?php echo e(url('/')); ?>/page/fav_services" class="dropdown-item">Layanan
                                        Favorit</a>
                                    <a href="<?php echo e(url('/')); ?>/page/monitoring"
                                        class="dropdown-item">Monitoring</a>
                                    <a href="<?php echo e(url('/')); ?>/page/api_documentation"
                                        class="dropdown-item">Dokumentasi
                                        API</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle arrow-none" href="javascript:;"
                                    data-bs-toggle="dropdown" role="button"><i
                                        class="mdi mdi-wallet-plus-outline me-2"></i>Deposit<div class="arrow-down">
                                    </div></a>
                                <div class="dropdown-menu">
                                    <a href="<?php echo e(url('/')); ?>/deposit/new" class="dropdown-item">Deposit Baru</a>
                                    <a href="<?php echo e(url('/')); ?>/deposit/history" class="dropdown-item">Riwayat
                                        Deposit</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle arrow-none" href="javascript:;"
                                    data-bs-toggle="dropdown" role="button"><i
                                        class="mdi mdi-email-multiple-outline me-2"></i>Tiket Bantuan
                                    <div class="arrow-down"></div>
                                </a>
                                <div class="dropdown-menu">
                                    <a href="<?php echo e(url('/')); ?>/ticket/new" class="dropdown-item">Tiket Baru</a>
                                    <a href="<?php echo e(url('/')); ?>/ticket/list" class="dropdown-item">Data Tiket</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle arrow-none" href="javascript:;"
                                    data-bs-toggle="dropdown" role="button"><i
                                        class="mdi mdi-account-convert me-2"></i>Log<div class="arrow-down"></div></a>
                                <div class="dropdown-menu">
                                    <a href="<?php echo e(url('/')); ?>/page/login_logs" class="dropdown-item">Masuk</a>
                                    <a href="<?php echo e(url('/')); ?>/page/balance_logs" class="dropdown-item">Penggunaan
                                        Saldo</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle arrow-none" href="javascript:;"
                                    data-bs-toggle="dropdown" role="button"><i
                                        class="mdi mdi-sitemap me-2"></i>Sitemap
                                    <div class="arrow-down"></div>
                                </a>
                                <div class="dropdown-menu">
                                    <a href="<?php echo e(url('/')); ?>/page/sitemap?id=1" class="dropdown-item">Kontak
                                        Kami</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="right-bar">
        <div data-simplebar class="h-100">
            <div class="rightbar-title d-flex align-items-center px-3 py-4">
                <h5 class="m-0 me-2">Pengaturan Mode</h5>
                <a href="javascript:void(0);" class="right-bar-toggle ms-auto">
                    <i class="mdi mdi-close noti-icon"></i>
                </a>
            </div>
            <hr class="mt-0" />
            <h6 class="text-center mb-0">Pilih Mode</h6>
            <div class="p-4">
                <div class="form-check form-switch mb-3">
                    <input class="form-check-input theme-choice" type="checkbox" id="light_mode" checked>
                    <label class="form-check-label" for="light_mode">Light Mode</label>
                </div>
                <div class="form-check form-switch mb-3">
                    <input class="form-check-input theme-choice" type="checkbox" id="dark_mode">
                    <label class="form-check-label" for="dark_mode">Dark Mode</label>
                </div>
            </div>
        </div>
    </div>
    <div class="rightbar-overlay"></div>
    <script src="<?php echo e(url('/')); ?>/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/libs/metismenu/metisMenu.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/libs/simplebar/simplebar.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/libs/node-waves/waves.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/libs/apexcharts/apexcharts.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/libs/select2/js/select2.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/js/app.js"></script>
    <?php echo $__env->yieldContent('script'); ?>
    <script type="text/javascript">
        $(window).keypress(function(event) {
            if (event.which == '13' && !$(event.target).is('textarea')) {
                event.preventDefault();
            }
        });
        $('.select2').select2();
        $('form').submit(function() {
            $(':submit').attr("disabled", true);
        });
        $('#light_mode').on('change', function() {
            if ($(this).is(':checked')) {
                document.cookie = "dark_theme=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                window.location.reload(true);
            }
        });
        $('#dark_mode').on('change', function() {
            if ($(this).is(':checked')) {
                document.cookie = "dark_theme=true; expires=Fri, 01 Dec 2023 09:35:27 +0700; path=/;";
                window.location.reload(true);
            }
        });

        function read_popup() {
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('/')); ?>/ajax/information"
            });
        }

        function confirm_logout() {
            Swal.fire({
                title: 'Yakin ingin keluar?',
                icon: 'question',
                html: 'Semua sesi Anda yang tersimpan akan dihapus.',
                showCancelButton: true,
                confirmButtonText: 'Keluar',
                cancelButtonText: 'Batalkan',
                customClass: {
                    confirmButton: 'btn btn-primary me-3',
                    cancelButton: 'btn btn-danger',
                },
                buttonsStyling: false,
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "<?php echo e(url('/')); ?>/logout";
                }
            });
        }

        function copy_text(title, text) {
            var dummy = document.createElement("textarea");
            document.body.appendChild(dummy);
            dummy.setAttribute("id", "dummy_id");
            document.getElementById("dummy_id").value = text;
            dummy.select();
            document.execCommand("copy");
            document.body.removeChild(dummy);
            Swal.fire({
                title: 'Yeay!',
                icon: 'success',
                html: title + ' berhasil disalin.',
                confirmButtonText: 'Okay',
                customClass: {
                    confirmButton: 'btn btn-primary',
                },
                buttonsStyling: false,
            });
        }
    </script>
    <script type="text/javascript">
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\smm\resources\views/templates/main.blade.php ENDPATH**/ ?>