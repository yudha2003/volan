<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.history-table', [])->html();
} elseif ($_instance->childHasBeenRendered('NbdK8el')) {
    $componentId = $_instance->getRenderedChildComponentId('NbdK8el');
    $componentTag = $_instance->getRenderedChildComponentTagName('NbdK8el');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NbdK8el');
} else {
    $response = \Livewire\Livewire::mount('admin.history-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('NbdK8el', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\volan\resources\views/admin/pesanan.blade.php ENDPATH**/ ?>