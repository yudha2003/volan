<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('all-layanan-table', [])->html();
} elseif ($_instance->childHasBeenRendered('ZIicLgx')) {
    $componentId = $_instance->getRenderedChildComponentId('ZIicLgx');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZIicLgx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZIicLgx');
} else {
    $response = \Livewire\Livewire::mount('all-layanan-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('ZIicLgx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\volan\resources\views/order/list-layanan.blade.php ENDPATH**/ ?>