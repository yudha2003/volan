
<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.history-table', [])->html();
} elseif ($_instance->childHasBeenRendered('MVEeQdU')) {
    $componentId = $_instance->getRenderedChildComponentId('MVEeQdU');
    $componentTag = $_instance->getRenderedChildComponentTagName('MVEeQdU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MVEeQdU');
} else {
    $response = \Livewire\Livewire::mount('admin.history-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('MVEeQdU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\smm\resources\views/admin/pesanan.blade.php ENDPATH**/ ?>