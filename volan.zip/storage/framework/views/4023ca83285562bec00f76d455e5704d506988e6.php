<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('deposit-table', [])->html();
} elseif ($_instance->childHasBeenRendered('weCKhxA')) {
    $componentId = $_instance->getRenderedChildComponentId('weCKhxA');
    $componentTag = $_instance->getRenderedChildComponentTagName('weCKhxA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('weCKhxA');
} else {
    $response = \Livewire\Livewire::mount('deposit-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('weCKhxA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\volan\resources\views/deposit/history.blade.php ENDPATH**/ ?>