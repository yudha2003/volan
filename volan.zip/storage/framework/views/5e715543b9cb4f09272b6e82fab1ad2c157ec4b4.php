<?php $__env->startSection('content'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.deposit-table')->html();
} elseif ($_instance->childHasBeenRendered('T5jPwo0')) {
    $componentId = $_instance->getRenderedChildComponentId('T5jPwo0');
    $componentTag = $_instance->getRenderedChildComponentTagName('T5jPwo0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T5jPwo0');
} else {
    $response = \Livewire\Livewire::mount('admin.deposit-table');
    $html = $response->html();
    $_instance->logRenderedChild('T5jPwo0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\volan\resources\views/admin/deposit_user.blade.php ENDPATH**/ ?>