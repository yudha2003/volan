<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.ticket-table', [])->html();
} elseif ($_instance->childHasBeenRendered('tju59tS')) {
    $componentId = $_instance->getRenderedChildComponentId('tju59tS');
    $componentTag = $_instance->getRenderedChildComponentTagName('tju59tS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tju59tS');
} else {
    $response = \Livewire\Livewire::mount('admin.ticket-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('tju59tS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\volan\resources\views/admin/list-ticket.blade.php ENDPATH**/ ?>