<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.deposit-table', [])->html();
} elseif ($_instance->childHasBeenRendered('OIhc9z4')) {
    $componentId = $_instance->getRenderedChildComponentId('OIhc9z4');
    $componentTag = $_instance->getRenderedChildComponentTagName('OIhc9z4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OIhc9z4');
} else {
    $response = \Livewire\Livewire::mount('admin.deposit-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('OIhc9z4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starsos1/laravel/resources/views/admin/deposit_user.blade.php ENDPATH**/ ?>