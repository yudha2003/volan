
<?php $__env->startSection('content'); ?>
<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Success!</strong> <?php echo session()->get('success'); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Error!</strong> <?php echo e(session()->get('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Error!</strong> <?php echo e($message); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <h5 class="card-header"><i class="mdi mdi-email-plus-outline me-1"></i>Tiket Baru</h5>
            <div class="card-body">
                <form method="POST" action="<?php echo e(url('ticket/proses')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Subjek <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="subject">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tipe <span class="text-danger">*</span></label>
                        <select class="form-control" name="type">
                            <option value="" selected disabled>Pilih...</option>
                            <option value="order">Pesanan</option>
                            <option value="deposit">Deposit</option>
                            <option value="other">Lainnya</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Pesan <span class="text-danger">*</span></label>
                        <textarea class="form-control" name="content" rows="4"></textarea>
                    </div>
                    <div class="mb-0">
                        <button type="submit" class="btn btn-primary waves-effect waves-light float-end"><i
                                class="mdi mdi-email-plus-outline me-1"></i>Kirim</button>
                        <button type="reset" class="btn btn-danger waves-effect waves-light float-end me-2"><i
                                class="mdi mdi-refresh me-1"></i>Ulangi</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <h5 class="card-header"><i class="mdi mdi-information-outline me-1"></i>Informasi</h5>
            <div class="card-body">
                <strong>Cara Membuat Tiket Baru :</strong>
                <ul>
                    <li>Input <em>Subjek</em> yang Anda inginkan.</li>
                    <li>Pilih <em>Tipe Tiket</em> (Pesanan, Deposit, Lainnya).</li>
                    <li>Kami akan segera merespon tiket Anda.</li>
                </ul>
                <strong>Penting !</strong>
                <ul>
                    <li>Kami berhak menghapus atau memblokir akun Anda apabila terbukti melakukan tindakan pelanggaran
                        pada Tiket.</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<script>
    $('.btn-primary').click(function(){
        var subject = $('input[name=subject]').val();
        var type = $('select[name=type]').val();
        var content = $('textarea[name=content]').val();
        if(subject == '' || type == 0 || content == ''){
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Mohon isi semua kolom yang tersedia !',
            });
            return false;
        } else {
            $(this).html('<i class="mdi mdi-loading mdi-spin me-1"></i>Proses...');
            $('form').submit();
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\smm\resources\views/tickets/new.blade.php ENDPATH**/ ?>