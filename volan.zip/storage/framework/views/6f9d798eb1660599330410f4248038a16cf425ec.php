
<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('all-layanan-table', [])->html();
} elseif ($_instance->childHasBeenRendered('K9QEa0J')) {
    $componentId = $_instance->getRenderedChildComponentId('K9QEa0J');
    $componentTag = $_instance->getRenderedChildComponentTagName('K9QEa0J');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('K9QEa0J');
} else {
    $response = \Livewire\Livewire::mount('all-layanan-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('K9QEa0J', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\smm\resources\views/order/list-layanan.blade.php ENDPATH**/ ?>