<div class="msg right-msg mt-3">
    <div class="msg-img" style="background-image: url(<?php echo e(URL::asset('assets/images/users.png')); ?>)">
    </div>

    <div class="msg-bubble">
        <div class="msg-info">
            <div class="msg-info-name"><?php echo e(Auth::user()->name); ?></div>
            <div class="msg-info-time"><?php echo e(\Carbon\Carbon::parse($last->created_at)->diffForHumans()); ?></div>
        </div>
        <div class="msg-text">
            <?php echo e($last->message); ?>

        </div>
    </div>
</div><?php /**PATH /home/starsos1/laravel/resources/views/tickets/user-send.blade.php ENDPATH**/ ?>