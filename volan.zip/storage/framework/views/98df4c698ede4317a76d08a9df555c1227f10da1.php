
<?php $__env->startSection('content'); ?>

    <div class="alert alert-info" role="alert">
        <i class="mdi mdi-information-outline me-1"></i> Hubungi Admin Support Mentoring Kami <b><em><a
                    href="https://wa.me/6285162904949">DISINI</a></em></b>.
    </div>
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <h5 class="card-header"><i class="mdi mdi-chart-line me-1"></i>Grafik 7 Hari Terakhir</h5>
                <div class="card-body">
                    <div id="user-chart" class="apex-charts" dir="ltr" style="height: 314px;"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex text-muted">
                        <div class="flex-shrink-0 me-3 align-self-center">
                            <div class="avatar-md">
                                <div class="avatar-title bg-soft-primary rounded-circle text-primary font-size-20">
                                    <i class="mdi mdi-wallet-outline fs-1"></i>
                                </div>
                            </div>
                        </div>
                        <div class="flex-grow-1 overflow-hidden">
                            <p class="mb-1">Total Saldo</p>
                            <h5 class="mb-1">Rp 0</h5>
                            <p class="text-truncate mb-0"> Saldo Anda <span class="text-success me-2"></span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="d-flex text-muted">
                        <div class="flex-shrink-0 me-3 align-self-center">
                            <div class="avatar-md">
                                <div class="avatar-title bg-soft-primary rounded-circle text-primary font-size-20">
                                    <i class="mdi mdi-cart-outline fs-1"></i>
                                </div>
                            </div>
                        </div>
                        <div class="flex-grow-1 overflow-hidden">
                            <p class="mb-1">Total Pemesanan</p>
                            <h5 class="mb-1">Rp 0</h5>
                            <p class="text-truncate mb-0">0 Pesanan</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="d-flex text-muted">
                        <div class="flex-shrink-0 me-3 align-self-center">
                            <div class="avatar-md">
                                <div class="avatar-title bg-soft-primary rounded-circle text-primary font-size-20">
                                    <i class="mdi mdi-cart-outline fs-1"></i>
                                </div>
                            </div>
                        </div>
                        <div class="flex-grow-1 overflow-hidden">
                            <p class="mb-1">Total Deposit</p>
                            <h5 class="mb-1">Rp 0</h5>
                            <p class="text-truncate mb-0">0 Deposit</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <h5 class="card-header"><i class="mdi mdi-bullhorn-outline me-1"></i>Informasi Terbaru</h5>
            <div class="card-body">
                <ul class="verti-timeline list-unstyled">
                    <li class="event-list">
                        <h5 class="fw-bold text-danger mb-1"><i class="mdi mdi-bug-outline me-1 fs-5"></i>Perbaikan</h5>
                        <p class="text-muted mb-2"><small>Kamis, 03 November 2022 - 02:59</small></p>
                        <p class="text-muted" style="margin-bottom: 8px;">
                        <p>Mohon maaf sebelumnya</p>
                        <p>ada ddos</p>
                        <p>sedang update big database</p>
                        </p>
                        <small class="text-muted">Pembaruan terakhir: Kamis, 03 November 2022 - 02:59</small>
                    </li>
                    <li class="event-list">
                        <h5 class="fw-bold text-success mb-1"><i class="mdi mdi-progress-wrench me-1 fs-5"></i>Layanan</h5>
                        <p class="text-muted mb-2"><small>Jumat, 21 Oktober 2022 - 19:05</small></p>
                        <p class="text-muted" style="margin-bottom: 8px;">
                        <p><span style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;">Aktifkan
                                layanan</span><br
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;"><span
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;">-
                                &nbsp;TIKTOK View Server 15 CHEAPEAST [ Max 10M ]&nbsp;</span><br
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;"><br
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;"><span
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;">Perubahan
                                layanan</span><br
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;"><span
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;">-
                                &nbsp;TIKTOK View Server 5 SuperFast CHEAP&nbsp;</span><br
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;"><br
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;"><span
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;">Nonaktifkan
                                layanan sementara karna overload</span><br
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;"><span
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;">-
                                &nbsp;Instagram Likes Indonesia 11 [LANGSUNGMASUK] [ NODROP] [30K] REAL ACCOUNT
                                BONUS 20% [ Refill 3Days ]&nbsp;</span><br
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;"><span
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;">-
                                &nbsp;Instagram Followers Indonesia S19 BONUS 20% [ max 500 murah real
                                ]&nbsp;</span><br
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;"><span
                                style="font-family: Montserrat, sans-serif; -webkit-text-size-adjust: 100%;">-
                                &nbsp;Instagram Story Views Indonesia [ All Story Views ] CHEAP BEST
                                SELLER</span><br></p>
                        </p>
                        <small class="text-muted">Pembaruan terakhir: Jumat, 21 Oktober 2022 - 19:05</small>
                    </li>
                </ul>
                <h6 class="text-center mt-4"><a href="https://gudangjasa.com/page/informations"
                        class="d-grid btn btn-primary btn-sm waves-effect waves-light">Lihat Semua</a></h6>
            </div>
        </div>
    </div>

<?php $__env->startSection('script'); ?>
    <script>
        var options = {
            colors: ['#2c8ef8'],
            series: [{
                name: 'Jumlah Pesanan',
                data: [0, 0, 0, 0, 0, 0, 0, 0, ]
            }],
            chart: {
                toolbar: {
                    show: false
                },
                height: 320,
                type: 'area',
                events: {
                    animationEnd: undefined,
                    beforeMount: undefined,
                    mounted: undefined,
                    updated: undefined,
                    click: undefined,
                    mouseMove: undefined,
                    legendClick: undefined,
                    markerClick: undefined,
                    selection: undefined,
                    dataPointSelection: undefined,
                    dataPointMouseEnter: undefined,
                    dataPointMouseLeave: undefined,
                    beforeZoom: undefined,
                    beforeResetZoom: undefined,
                    zoomed: undefined,
                    scrolled: undefined,
                    scrolled: undefined,
                }
            },
            dataLabels: {
                enabled: false,
            },
            stroke: {
                curve: 'smooth'
            },
            markers: {
                size: 5,
                discrete: [{
                        seriesIndex: 0,
                        dataPointIndex: 0,
                        size: 0
                    },
                    {
                        seriesIndex: 0,
                        dataPointIndex: 1,
                        fillColor: '#2c8ef8',
                        strokeColor: '#fff',
                        size: 6
                    }
                ]
            },
            xaxis: {
                type: 'category',
                categories: ['24 Nov 2022', '25 Nov 2022', '26 Nov 2022', '27 Nov 2022', '28 Nov 2022', '29 Nov 2022',
                    '30 Nov 2022', '01 Des 2022',
                ],
                labels: {
                    trim: false,
                    rotate: 0,
                }
            },
            yaxis: {
                labels: {
                    formatter: function(value) {
                        return value + "";
                    }
                },
            },
            tooltip: {
                x: {
                    format: 'dd/MM/yy HH:mm'
                },
            },
        };
        var chart = new ApexCharts(document.querySelector("#user-chart"), options);
        chart.render();
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smm\resources\views/user/dashboard.blade.php ENDPATH**/ ?>