<div class="row">
    <div class="col-md-12">
        <div class="btn-group flex-wrap mb-3">
            <button wire:click="all" class="btn btn-primary">Semua</button>
            <button wire:click="refill" class="btn btn-primary ">Refill</button>
            <button wire:click="custom_comments" class="btn btn-primary ">Custom Comments</button>
            <button wire:click="custom_link" class="btn btn-primary ">Custom Link</button>
        </div>
        <div class="card">
            <h5 class="card-header"><i class="mdi mdi-history me-1"></i>All Layanan</h5>
            <div class="card-body">
                <form method="get" class="row">
                    <div class="col-md-3">
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Tampilkan</span>
                            </div>
                            <select class="form-control" name="row" id="table-row">
                                <option value="10">10</option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                            </select>
                            <div class="input-group-append">
                                <span class="input-group-text">baris.</span>
                            </div>
                        </div>
                    </div>
                    <?php echo \Livewire\Livewire::styles(); ?>

                    <div class="col-md-6">
                        <select class="select2 form-control" style="width:100%" name="category" id="category">
                            <option value="">Semua Kategori</option>
                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($rows->category); ?>"><?php echo e($rows->category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group mb-3">
                            <input type="text" wire:model.debounce.300ms="search" class="form-control" name="search"
                                id="table-search" value="" placeholder="Cari...">
                        </div>
                    </div>
                </form>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr class="text-uppercase">
                                <th>Service ID</th>
                                <th>Favorit</th>
                                <th>Category</th>
                                <th>Nama Layanan</th>
                                <th>Harga/ 1000 </th>
                                <th>Min Pesan</th>
                                <th>Max Pesan</th>
                                <th>Average Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($layanan->count() > 0): ?>
                            <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            if ($row->average_time != ' Not enough data.') {
                            $explode = explode('waktu proses', $row->average_time);
                            $explode = trim($explode[1]);
                            } else {
                            $explode = $row->average_time;
                            }
                            $favorit = App\Models\Favorit::where('user_id', Auth::user()->id)->where([['service_id',
                            $row->service_id],
                            ['category', $row->category], ['layanan',$row->name]])->first();
                            ?>
                            <tr>
                                <td><?php echo e($row->service_id); ?></td>
                                <?php if($favorit): ?>
                                <td class="text-center"><a href="javascript:;"
                                        onclick="unfav('<?php echo e($row->service_id); ?>');" id="fs-<?php echo e($row->service_id); ?>"><i
                                            class="mdi mdi-star text-primary ms-1 font-size-20"></i></a></td>
                                <?php else: ?>
                                <td class="text-center"><a href="javascript:;" onclick="fav('<?php echo e($row->service_id); ?>');"
                                        id="fs-<?php echo e($row->service_id); ?>"><i
                                            class="mdi mdi-star-outline text-primary ms-1 font-size-20"></i></a></td>
                                <?php endif; ?>
                                <td><?php echo e($row->category); ?></td>
                                <td><?php echo e($row->name); ?></td>
                                <td><?php echo e(number_format($row->price, 0, ',', '.')); ?></td>
                                <td><?php echo e(number_format($row->min, 0, ',', '.')); ?></td>
                                <td><?php echo e(number_format($row->max, 0, ',', '.')); ?></td>
                                <td><?php echo e($explode); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center">Data Not Found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo $layanan->links(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $('#category').change(function(){
        var category = $(this).val();
        Livewire.emit('category', category);
    });
    function fav(id) {
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('favorit/service')); ?>",
            data: "id=" + id + "&_token=<?php echo e(csrf_token()); ?>",
            dataType: "json",
            success: function(data) {
                if (data.status == true) {
                    $('#fs-' + id).html('<i class="mdi mdi-star text-primary ms-1 font-size-20"></i>');
                    $('#fs-' + id).attr('onclick', 'unfav(\'' + id + '\');');
                    Swal.fire({
                        title: 'Berhasil',
                        icon: 'success',
                        html: data.message,
                        confirmButtonText: 'OK',
                        customClass: {
                            confirmButton: 'btn btn-primary',
                        },
                        buttonsStyling: false,
                    });
                } else {
                    Swal.fire({
                        title: 'Ups!',
                        icon: 'error',
                        html: data.message,
                        confirmButtonText: 'OK',
                        customClass: {
                            confirmButton: 'btn btn-primary',
                        },
                        buttonsStyling: false,
                    });
                }
            },
            error: function() {
                Swal.fire({
                    title: 'Ups!',
                    icon: 'error',
                    html: 'Terjadi kesalahan, silahkan coba lagi.',
                    confirmButtonText: 'OK',
                    customClass: {
                        confirmButton: 'btn btn-primary',
                    },
                    buttonsStyling: false,
                });
            },
            beforeSend: function() {}
        });
    }

    function unfav(id) {
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('unfav/service')); ?>",
            data: "id=" + id + "&_token=<?php echo e(csrf_token()); ?>",
            dataType: "json",
            success: function(data) {
                if (data.status == true) {
                    $('#fs-' + id).html('<i class="mdi mdi-star-outline text-primary ms-1 font-size-20"></i>');
                    $('#fs-' + id).attr('onclick', 'fav(\'' + id + '\');');
                    Swal.fire({
                        title: 'Berhasil!',
                        icon: 'success',
                        html: data.message,
                        confirmButtonText: 'OK',
                        customClass: {
                            confirmButton: 'btn btn-primary',
                        },
                        buttonsStyling: false,
                    });
                } else {
                    Swal.fire({
                        title: 'Ups!',
                        icon: 'error',
                        html: data.message,
                        confirmButtonText: 'OK',
                        customClass: {
                            confirmButton: 'btn btn-primary',
                        },
                        buttonsStyling: false,
                    });
                }
            },
            error: function() {
                Swal.fire({
                    title: 'Ups!',
                    icon: 'error',
                    html: 'Terjadi kesalahan, silahkan coba lagi.',
                    confirmButtonText: 'OK',
                    customClass: {
                        confirmButton: 'btn btn-primary',
                    },
                    buttonsStyling: false,
                });
            },
            beforeSend: function() {}
        });
    }
</script><?php /**PATH C:\xampp\htdocs\laravel\smm\resources\views/livewire/all-layanan-table.blade.php ENDPATH**/ ?>