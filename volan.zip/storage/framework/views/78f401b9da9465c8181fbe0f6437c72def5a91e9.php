<?php $__env->startSection('content'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.single-general')->html();
} elseif ($_instance->childHasBeenRendered('Dc6Y4nZ')) {
    $componentId = $_instance->getRenderedChildComponentId('Dc6Y4nZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('Dc6Y4nZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Dc6Y4nZ');
} else {
    $response = \Livewire\Livewire::mount('order.single-general');
    $html = $response->html();
    $_instance->logRenderedChild('Dc6Y4nZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\volan\resources\views/order/single.blade.php ENDPATH**/ ?>