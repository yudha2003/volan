<div>
    <div class="row">
        <div class="col-md-!2">
            <div class="card">
                <h5 class="card-header"><i class="mdi mdi-message-draw"></i>Tambah Layanan
                    <div class="float-end" style="cursor: pointer;">
                        <i class="mdi mdi-arrow-down"></i>
                    </div>
                </h5>
                <div class="card-body" id="card-toggle">
                    <form wire:submit.prevent="savednews">
                        <div class="row">
                            <div class="col-md">
                                <label class="form-label">Service ID<span class="text-danger">*</span></label>
                                <input type="text" name="service_id" placeholder="Masukkan Service ID"
                                    wire:model="service_id" id="service_id" class="form-control">
                                <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md">
                                <label class="form-label">Category<span class="text-danger">*</span></label>
                                <input type="text" name="category" placeholder="Masukkan code payment"
                                    wire:model="category" id="category" class="form-control">
                                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md">
                                <label class="form-label">Nama Layanan <span class="text-danger">*</span></label>
                                <input type="text" name="name" placeholder="Masukkan name layanan"
                                    wire:model="name" id="name" class="form-control">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md">
                                <label for="" class="form-label">Harga / 1000<span
                                        class="text-danger">*</span></label>
                                <div class="input-group">
                                    <div class="input-group-text">Rp</div>
                                    <input type="number" class="form-control" wire:model="price"
                                        placeholder="Masukkan harga produk" name="harga" id="harga">
                                </div>
                                <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md">
                                <label for="" class="form-label">Min<span class="text-danger">*</span></label>
                                <input type="number" name="min" id="min" wire:model="min"
                                    placeholder="Masukkan min transaksi" class="form-control">
                                <?php $__errorArgs = ['min'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md">
                                <label for="" class="form-label">Max<span class="text-danger">*</span></label>
                                <input type="number" name="max" id="max" wire:model="max"
                                    placeholder="Masukkan max transaksi" class="form-control">
                                <?php $__errorArgs = ['max'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <label for="" class="form-label mt-2">Description<span
                                class="text-danger">*</span></label>
                        <textarea name="description" placeholder="Masukkan deskripsi" id="description" wire:model="description"
                            class="form-control" cols="30" rows="2"></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="float-end mt-2">
                            <button class="btn btn-danger" type="reset">Reset</button>
                            <button class="btn btn-primary" type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="btn-group flex-wrap mb-3">
                <button wire:click="all" class="btn btn-primary" id="filter">Semua</button>
                <button wire:click="refill" class="btn btn-primary " id="filter">Refill</button>
                <button wire:click="custom_comments" class="btn btn-primary " id="filter">Custom Comments</button>
                <button wire:click="custom_link" class="btn btn-primary " id="filter">Custom Link</button>
            </div>
            <div class="card">
                <h5 class="card-header"><i class="mdi mdi-history me-1"></i>All Layanan</h5>
                <div class="card-body">
                    <form method="get" class="row">
                        <div class="col-md-3">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Tampilkan</span>
                                </div>
                                <select wire:model="perPage" class="form-control" name="row" id="table-row">
                                    <option value="10">10</option>
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                                <div class="input-group-append">
                                    <span class="input-group-text">baris.</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-3">
                            <div class="input-group mb-3">
                                <input type="text" wire:model.debounce.300ms="search" class="form-control"
                                    name="search" id="table-search" value="" placeholder="Cari...">
                            </div>
                        </div>
                    </form>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr class="text-uppercase">
                                    <th>Service ID</th>
                                    <th>Category</th>
                                    <th>Nama Layanan</th>
                                    <th>Description</th>
                                    <th>Harga/ 1000 </th>
                                    <th>Min Pesan</th>
                                    <th>Max Pesan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($layanan->count() > 0): ?>
                                    <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $favorit = App\Models\Favorit::where('user_id', Auth::user()->id)
                                                ->where([['service_id', $row->service], ['category', $row->category], ['layanan', $row->name]])
                                                ->first();
                                        ?>
                                        <tr>
                                            <td><?php echo e($row->service); ?></td>
                                            <td><?php echo e($row->category); ?></td>
                                            <td><?php echo e($row->name); ?></td>
                                            <td>
                                                <textarea cols="50" rows="5" class="form-control" readonly><?php echo e(trim($row->description)); ?></textarea>
                                            </td>
                                            <td><?php echo e(number_format($row->price, 0, ',', '.')); ?></td>
                                            <td><?php echo e(number_format($row->min, 0, ',', '.')); ?></td>
                                            <td><?php echo e(number_format($row->max, 0, ',', '.')); ?></td>
                                            <td class="text-nowrap">
                                                <button class="btn btn-primary btn-sm" id="edit">Edit</button>
                                                <button class="btn btn-danger btn-sm"
                                                    wire:click.prevent="deleteLayanan(<?php echo e($row->service); ?>)">Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center">Data Not Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo $layanan->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    // if button edit clicked add attr input where table row
    $(document).on('click', '#edit', function() {
        var row = $(this).closest('tr');
        var service_id = row.find('td:eq(0)').text();
        var category = row.find('td:eq(1)').text();
        var layanan = row.find('td:eq(2)').text();
        var description = row.find('td:eq(3)').text();
        var harga = row.find('td:eq(4)').text();
        var min = row.find('td:eq(5)').text();
        var max = row.find('td:eq(6)').text();
        var aksi = row.find('td:eq(7)').text();
        row.find('td:eq(0)').html(
            '<input type="text" class="form-control form-control-sm" name="service_id" value="' +
            service_id +
            '">');
        row.find('td:eq(1)').html(
            '<input type="text" class="form-control form-control-sm" name="category" value="' + category +
            '">');
        row.find('td:eq(2)').html(
            '<input type="text" class="form-control form-control-sm" name="layanan" value="' + layanan +
            '">');
        row.find('td:eq(3)').html(
            '<textarea cols="15" rows="10" class="form-control" name="description">' + description +
            '</textarea>');
        row.find('td:eq(4)').html(
            '<input type="text" class="form-control form-control-sm" name="harga" value="' + harga + '">');
        row.find('td:eq(5)').html('<input type="text" class="form-control form-control-sm" name="min" value="' +
            min + '">');
        row.find('td:eq(6)').html('<input type="text" class="form-control form-control-sm" name="max" value="' +
            max + '">');
        row.find('td:eq(7)').html(
            '<button class="btn btn-success btn-sm" style="width:100%" id="save">Save</button>');
    });
    // if button save clicked add attr input where table row
    $(document).on('click', '#save', function() {
        var row = $(this).closest('tr');
        var service_id = row.find('td:eq(0) input').val();
        var category = row.find('td:eq(1) input').val();
        var layanan = row.find('td:eq(2) input').val();
        var description = row.find('td:eq(3) textarea').val();
        var harga = row.find('td:eq(4) input').val();
        var min = row.find('td:eq(5) input').val();
        var max = row.find('td:eq(6) input').val();
        var aksi = row.find('td:eq(7)').text();
        row.find('td:eq(0)').html(service_id);
        row.find('td:eq(1)').html(category);
        row.find('td:eq(2)').html(layanan);
        row.find('td:eq(3)').html(description);
        row.find('td:eq(4)').html(harga);
        row.find('td:eq(5)').html(min);
        row.find('td:eq(6)').html(max);
        row.find('td:eq(7)').html(
            '<button class="btn btn-primary btn-sm" id="edit">Edit</button> <button class="btn btn-danger btn-sm" wire:click.prevent="deleteLayanan(<?php echo e($row->id); ?>)">Delete</button>'
        );
        var btn = document.querySelectorAll('#edit');
        btn.forEach(function(item) {
            item.classList.add('btn-primary');
        });
        var filter = document.querySelectorAll('#filter');
        filter.forEach(function(item) {
            item.classList.add('btn-primary');
        });
        $.ajax({
            url: "<?php echo e(route('layanan.update')); ?>",
            type: "POST",
            data: {
                service_id: service_id,
                category: category,
                layanan: layanan,
                harga: harga,
                description: description,
                min: min,
                max: max,
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(response) {
                if (response.status == 'error') {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: response.message,
                    })
                }
            }
        });
    });
    window.addEventListener('confirm-delete', event => {
        Swal.fire({
            title: 'Apakah Anda Yakin?',
            text: "Data yang dihapus tidak dapat dikembalikan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Hapus!'
        }).then((result) => {
            if (result.isConfirmed) {
                Livewire.emit('deleteLayanan')
            }
        })
    });
    window.addEventListener('deleted', event => {
        Swal.fire(
            'Gagal!',
            'Data Berhasil Dihapus',
            'success'
        )
    });
    window.addEventListener('success', event => {
        Swal.fire(
            'Berhasil!',
            event.detail.message,
            'success'
        )
    });
    window.addEventListener('failed', event => {
        Swal.fire(
            'Gagal!',
            event.detail.message,
            'error'
        )
    });
</script>
<?php /**PATH /home/starsos1/laravel/resources/views/livewire/admin/layanan-table.blade.php ENDPATH**/ ?>