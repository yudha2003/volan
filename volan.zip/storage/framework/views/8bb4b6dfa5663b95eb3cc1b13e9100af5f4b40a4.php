
<?php $__env->startSection('content'); ?>
    <?php
        use Carbon\Carbon;
        function tanggal($tanggal)
        {
            $bulan = [
                1 => 'Januari',
                'Februari',
                'Maret',
                'April',
                'Mei',
                'Juni',
                'Juli',
                'Agustus',
                'September',
                'Oktober',
                'November',
                'Desember',
            ];
            $pecahkan = explode('-', $tanggal);
        
            // variabel pecahkan 0 = tanggal
            // variabel pecahkan 1 = bulan
            // variabel pecahkan 2 = tahun
        
            return $pecahkan[2] . ' ' . $bulan[(int) $pecahkan[1]] . ' ' . $pecahkan[0];
        }
    ?>
    <div class="col-md-12">
        <div class="card">
            <h5 class="card-header"><i class="mdi mdi-bullhorn-outline me-1"></i>Informasi Terbaru</h5>
            <div class="card-body">
                <ul class="verti-timeline list-unstyled">
                    <?php
                        $berita = App\Models\Announcement::orderBy('id', 'DESC')->get();
                        $berita2 = App\Models\Announcement::orderBy('id', 'asc')->get();
                        $first = $berita2->first();
                    ?>
                    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            if ($row->type == 'info') {
                                $type = 'primary';
                                $icon = 'mdi mdi-information-outline';
                                $text = 'Informasi';
                            } else {
                                $type = 'success';
                                $icon = 'mdi mdi-progress-wrench';
                                $text = 'Layanan';
                            }
                        ?>
                        <li class="event-list">
                            <h5 class="fw-bold text-<?php echo e($type); ?> mb-1"><i
                                    class="<?php echo e($icon); ?> me-1 fs-5"></i><?php echo e($text); ?></h5>
                            <p class="text-muted mb-2">
                                <small><?php echo e(tanggal(Carbon::parse($row->created_at)->format('Y-m-d'))); ?> -
                                    <?php echo e(Carbon::parse($row->created_at)->format('H:i')); ?></small>
                            </p>
                            <p class="text-muted" style="margin-bottom: 8px;">
                            <p>
                                <?php
                                    $row->message = nl2br($row->message);
                                    $row->message = preg_replace('/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/', '<a href="$0" target="_blank">$0</a>', $row->message);
                                    
                                ?>
                                <?php echo $row->message; ?>

                            </p>
                            <?php if($row->id == $first->id): ?>
                                <b><small class="text-muted">Pembaruan terakhir:
                                        <?php echo e(tanggal(Carbon::parse($row->created_at)->format('Y-m-d'))); ?> -
                                        <?php echo e(Carbon::parse($row->created_at)->format('H:i')); ?></small></b>
                            <?php endif; ?>
                        </li>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\smm\resources\views/user/berita.blade.php ENDPATH**/ ?>