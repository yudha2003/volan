
<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.ticket-table', [])->html();
} elseif ($_instance->childHasBeenRendered('Juhp6BX')) {
    $componentId = $_instance->getRenderedChildComponentId('Juhp6BX');
    $componentTag = $_instance->getRenderedChildComponentTagName('Juhp6BX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Juhp6BX');
} else {
    $response = \Livewire\Livewire::mount('admin.ticket-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('Juhp6BX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\smm\resources\views/admin/list-ticket.blade.php ENDPATH**/ ?>