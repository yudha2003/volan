<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('log-login-table', [])->html();
} elseif ($_instance->childHasBeenRendered('qtLjXuQ')) {
    $componentId = $_instance->getRenderedChildComponentId('qtLjXuQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('qtLjXuQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qtLjXuQ');
} else {
    $response = \Livewire\Livewire::mount('log-login-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('qtLjXuQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starsos1/laravel/resources/views/user/log-login.blade.php ENDPATH**/ ?>