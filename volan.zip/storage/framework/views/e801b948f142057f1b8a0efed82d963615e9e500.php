<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('ticket-table', [])->html();
} elseif ($_instance->childHasBeenRendered('dHfxlud')) {
    $componentId = $_instance->getRenderedChildComponentId('dHfxlud');
    $componentTag = $_instance->getRenderedChildComponentTagName('dHfxlud');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dHfxlud');
} else {
    $response = \Livewire\Livewire::mount('ticket-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('dHfxlud', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\volan\resources\views/tickets/history.blade.php ENDPATH**/ ?>