<?php
    
    function tanggal($tanggal)
    {
        $bulan = [
            1 => 'Januari',
            'Februari',
            'Maret',
            'April',
            'Mei',
            'Juni',
            'Juli',
            'Agustus',
            'September',
            'Oktober',
            'November',
            'Desember',
        ];
        $pecahkan = explode('-', $tanggal);
    
        // variabel pecahkan 0 = tanggal
        // variabel pecahkan 1 = bulan
        // variabel pecahkan 2 = tahun
    
        return $pecahkan[2] . ' ' . $bulan[(int) $pecahkan[1]] . ' ' . $pecahkan[0];
    }
?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong><?php echo e(session('error')); ?></strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php elseif(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo e(session('success')); ?></strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> <?php echo e($error); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div>
    <div class="row">
        <div class="col-md-!2">
            <div class="card">
                <h5 class="card-header"><i class="mdi mdi-message-draw"></i>Tambah metode pembayaran
                    <div class="float-end" style="cursor: pointer;">
                        <i class="mdi mdi-arrow-down"></i>
                    </div>
                </h5>
                <div class="card-body" id="card-toggle">
                    <form wire:submit.prevent="savednews">
                        <div class="row">
                            <div class="col-md">
                                <label class="form-label">Type Process <span class="text-danger">*</span></label>
                                <select name="type" id="type" class="form-control" wire:model="type">
                                    <option value="">Pilih Type Process</option>
                                    <option value="auto">Otomatis</option>
                                    <option value="manual">Manual</option>
                                </select>
                                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md">
                                <label class="form-label">Code Payment <span class="text-danger">*</span></label>
                                <input type="text" name="code" placeholder="Masukkan code payment"
                                    wire:model="code" id="code" class="form-control">
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md">
                                <label for="" class="form-label">Name Payment <span
                                        class="text-danger">*</span></label>
                                <input type="text" name="name" wire:model="name"
                                    placeholder="Masukkan nama payment" id="name" class="form-control">
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md">
                                <label for="" class="form-label">Rate<span class="text-danger">*</span></label>
                                <input type="number" name="rate" id="rate" wire:model="rate"
                                    placeholder="Masukkan rate berdasarkan %" class="form-control">
                                <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md">
                                <label for="" class="form-label">Name Account<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="account_name" id="account_name" wire:model="account_name"
                                    placeholder="Masukkan Name Account" class="form-control">
                                <?php $__errorArgs = ['account_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md">
                                <label for="" class="form-label">Number Account<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="account_number" id="account_number"
                                    wire:model="account_number" placeholder="Masukkan Number Account"
                                    class="form-control">
                                <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <label for="" class="form-label mt-2">Description<span
                                class="text-danger">*</span></label>
                        <textarea name="description" placeholder="Masukkan deskripsi" id="description" wire:model="description"
                            class="form-control" cols="30" rows="2"></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="float-end mt-2">
                            <button class="btn btn-danger" type="reset">Reset</button>
                            <button class="btn btn-info" type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="btn-group flex-wrap mb-3">
                <button wire:click="all" class="btn btn-primary">Semua</button>
                <button wire:click="active" class="btn btn-primary">Active</button>
                <button wire:click="nonaktif" class="btn btn-primary">Nonaktif</button>
            </div>
            <div class="card">
                <h5 class="card-header"><i class="mdi mdi-ticket me-1"></i>Metode Pembayaran</h5>
                <div class="card-body">
                    <form method="get" class="row">
                        <div class="col-md-3">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Tampilkan</span>
                                </div>
                                <select wire:model="perPage" class="form-control" name="row" id="table-row">
                                    <option value="10">10</option>
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                                <div class="input-group-append">
                                    <span class="input-group-text">baris.</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-3">
                            <div class="input-group mb-3">
                                <input type="text" wire:model.debounce.300ms="search" class="form-control"
                                    name="search" id="table-search" value="" placeholder="Cari...">
                            </div>
                        </div>
                    </form>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr class="text-uppercase">
                                    <th>ID</th>
                                    <th>Process</th>
                                    <th>Code</th>
                                    <th>Name Payment</th>
                                    <th>Rate Type</th>
                                    <th>Rate</th>
                                    <th>Name Account</th>
                                    <th>Number Account</th>
                                    <th>Deskripsi</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                    <th> </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($list->count() > 0): ?>
                                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            if ($row->status == 'inactive') {
                                                $status = 'danger';
                                                $text = 'Nonaktif';
                                            } elseif ($row->status == 'active') {
                                                $status = 'success';
                                                $text = 'Aktif';
                                            }
                                        ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($row->process); ?></td>
                                            <td><?php echo e($row->code); ?></td>
                                            <td><?php echo e($row->name); ?></td>
                                            <td><?php echo e($row->rate_type); ?></td>
                                            <?php if($row->rate_type == 'percent'): ?>
                                                <td><?php echo e($row->rate); ?>%</td>
                                            <?php else: ?>
                                                <td><?php echo e($row->rate); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($row->account_name); ?></td>
                                            <td><?php echo e($row->account_number); ?></td>
                                            <td><?php echo e($row->description); ?></td>
                                            <td><span
                                                    class="btn btn-soft-<?php echo e($status); ?> btn-sm "><?php echo e($text); ?></span>
                                            </td>
                                            <td class="text-nowrap">
                                                <button class="btn btn-primary btn-sm"
                                                    id="edit">Edit</button></button>
                                                <?php if($row->status == 'active'): ?>
                                                    <button class="btn btn-danger btn-sm"
                                                        wire:click.prevent='nonaktifkan(<?php echo e($row->id); ?>)'>
                                                        Nonaktifkan
                                                    </button>
                                                <?php else: ?>
                                                    <button class="btn btn-success btn-sm"
                                                        wire:click.prevent='aktifkan(<?php echo e($row->id); ?>)'>
                                                        Aktifkan
                                                    </button>
                                                <?php endif; ?>
                                                <button class="btn btn-danger btn-sm"
                                                    wire:click.prevent="deleteMetode(<?php echo e($row->id); ?>)"><i
                                                        class="mdi mdi-delete"></i></button>
                                            </td>
                                            <td></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center">Data Not Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo $list->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg">
        <div class="card">
            <h5 class="card-header"><i class="mdi mdi-ticket me-1"></i>Gopay</h5>

            <?php
                $search = App\Models\Gopay::where([['status', 'active']])->first();
            ?>
            <?php if(!$search): ?>
                <form action="<?php echo e(url('koneksi/encrypt/gopay')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <label class="col-form-label fw-semibold fs-6 pt-0">Nomor Handphone</label>

                        <div class="input-group input-group-solid">
                            <input type="hidden" name="otptoken" id="gopay_otptoken" />
                            <input type="number" name="phonenumber" id="gopay_phonenumber"
                                class="form-control mb-3 mb-lg-0" placeholder="Masukkan Nomor Handphone"
                                value="" required />
                            <button type="button" class="btn btn-primary btn-sm" onclick="otpgopay()">
                                Kirim Kode OTP
                            </button>
                        </div>
                        <div class="mb-7 mt-2">
                            <label class="col-form-label fw-semibold fs-6 pt-0">Kode OTP</label>

                            <div class="input-group input-group-solid">
                                <input type="number" name="otpcode" id="gopay_otpcode"
                                    class="form-control mb-3 mb-lg-0" placeholder="Masukkan Kode OTP" required />

                                <button type="button" class="btn btn-primary" id="gopay_login"
                                    onclick="loginGopay()" disabled>
                                    Login
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            <?php else: ?>
                <div class="d-flex justify-content-center mb-3 py-6 px-9">
                    <button type="submit" class="btn btn-info" onclick="changeaccount('gopay')">
                        Change Account
                    </button>
                    <button type="submit" style="margin-left: 8px;" onclick="mutasigopay()"
                        class="btn btn-success">
                        Cek Mutasi
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg">


        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <div class="card-title">E Wallet OVO</div>
                </div>
            </div>

            <?php
                $search = App\Models\Ovo::where([['status', 'active']])->first();
            ?>
            <?php if(!$search): ?>
                <form action="<?php echo e(url('koneksi/encrypt/ovo')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <label for="">No. Handphone</label>

                        <div class="input-group input-group-solid">
                            <input type="hidden" name="otptoken" id="ovo_otptoken" />
                            <input type="number" name="phonenumber" id="ovo_phonenumber"
                                class="form-control form-control-solid mb-3 mb-lg-0"
                                placeholder="Masukkan Nomor Handphone" required />
                            <button type="button" class="btn btn-primary btn-sm" onclick="otpOvo()">
                                Kirim Kode OTP
                            </button>
                        </div>

                        <div class="mb-7 mt-2">
                            <label class="col-form-label fw-semibold fs-6 pt-0">Kode OTP</label>

                            <div class="input-group input-group-solid">
                                <input type="text" name="pin" id="ovo_pins"
                                    class="form-control form-control-solid mb-3 mb-lg-0"
                                    placeholder="Masukkan Pin Account" required />
                                <button type="button" class="btn btn-primary btn-sm" id="ovo_logins"
                                    onclick="loginOvo()">
                                    Login
                                </button>
                            </div>
                        </div>
                        <div class="mb-7 mt-2">
                            <label class="col-form-label fw-semibold fs-6 pt-0">Pin Account</label>
                            <div class="input-group input-group-solid">
                                <input type="password" name="pin" id="ovo_pin"
                                    class="form-control form-control-solid mb-3 mb-lg-0"
                                    placeholder="Masukkan Pin Account" required />
                                <button type="button" class="btn btn-primary btn-sm" id="ovo_logins"
                                    onclick="pinOVO()">
                                    Submit Pin
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            <?php else: ?>
                <div class="d-flex justify-content-center mb-3 py-6 px-9">
                    <button type="submit" class="btn btn-info" onclick="changeaccount('ovo')">
                        Change Account
                    </button>
                    <button type="submit" style="margin-left: 8px;" onclick="mutasiovo()" class="btn btn-success">
                        Cek Mutasi
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md">
        <div class="card" id="blockui">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <div class="card-title">All Mutasi</div>
                </div>
            </div>
            <div class="card-body">
                <div id="mutasi"></div>
            </div>
        </div>
    </div>
</div>
<script>
    function changeaccount(data) {
        Swal.fire({
            title: 'Apakah anda yakin?',
            text: "Anda akan mengganti akun bank BCA anda!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, ganti!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "<?php echo e(url('admin/koneksi/encrypt/changeaccount')); ?>",
                    type: "POST",
                    data: {
                        data: data,
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(data) {
                        Swal.fire(
                            'Berhasil!',
                            data.message,
                            'success'
                        ).then((result) => {
                            location.reload();
                        })
                    },
                    error: function(data) {
                        Swal.fire(
                            'Gagal!',
                            'Gagal mengganti akun',
                            'error'
                        )
                    }
                })
            }
        })
    }


    function mutasibca() {
        $('#blockui').block({
            message: '<div class="spinner-grow text-primary" role="status"><span class="visually-hidden">Loading...</span><div>',
            timeout: 10000,
        });
        $.ajax({
            url: "<?php echo e(route('koneksi.encrypt.bank-bca.mutasi')); ?>",
            type: "POST",
            dataType: "html",
            data: {
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(data) {
                $('#blockui').unblock();
                $('#mutasi').html(data);
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong!',
                });
                $('#mutasi').html('');
            }
        });
    }

    function mutasigopay() {
        $('#blockui').block({
            message: '<div class="spinner-grow text-primary" role="status"><span class="visually-hidden">Loading...</span><div>',
            timeout: 10000,
        });
        $.ajax({
            url: "<?php echo e(route('koneksi.encrypt.gopay.mutasi')); ?>",
            type: "POST",
            dataType: "html",
            data: {
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(data) {
                $('#blockui').unblock();
                $('#mutasi').html(data);
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong!',
                });
                $('#mutasi').html('');
            }
        });
    }

    function mutasiovo() {
        $('#blockui').block({
            message: '<div class="spinner-grow text-primary" role="status"><span class="visually-hidden">Loading...</span><div>',
            timeout: 10000,
        });
        $.ajax({
            url: "<?php echo e(route('koneksi.encrypt.ovo.mutasi')); ?>",
            type: "POST",
            dataType: "html",
            data: {
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(data) {
                $('#blockui').unblock();
                $('#mutasi').html(data);
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong!',
                });
                $('#mutasi').html('');
            }
        });
    }
    window.addEventListener('save-confirmation', event => {
        var id = event.detail.id;
        var code = $('#code-' + id).val();
        var name = $('#name-' + id).val();
        var rate = $('#rate-' + id).val();
        var account_number = $('#account_number-' + id).val();
        var account_name = $('#account_name-' + id).val();
        var description = $('#description-' + id).val();
        var process = $('#process-' + id).val();
        Livewire.emit('saved', id, code, name, rate, account_number, account_name, description, process)
    });
    window.addEventListener('success', event => {
        $('#type').val('');
        $('#code').val('');
        $('#name').val('');
        $('#rate').val('');
        $('#account_number').val('');
        $('#account_name').val('');
        $('#description').val('');
        Swal.fire(
            'Terhapus!',
            event.detail.message,
            'success'
        )
    });
    window.addEventListener('failed', event => {
        Swal.fire(
            'Gagal!',
            event.detail.message,
            'error'
        )
    });
    $('button[type=reset]').click(function() {
        $('#code').val('');
        $('#name').val('');
        $('#rate').val('');
        $('#account_number').val('');
        $('#account_name').val('');
        $('#description').val('');
    });
    window.addEventListener('delete-confirmation', event => {
        Swal.fire({
            title: 'Apakah Anda Yakin?',
            text: "Data yang dihapus tidak dapat dikembalikan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Hapus!'
        }).then((result) => {
            if (result.isConfirmed) {
                Livewire.emit('deleteMetode')
            }
        })
    });

    // if button edit clicked add attr input where table row
    $(document).on('click', '#edit', function() {
        var tr = $(this).closest('tr');
        var id = tr.find('td:eq(0)').text();
        var process = tr.find('td:eq(1)').text();
        var code = tr.find('td:eq(2)').text();
        var name = tr.find('td:eq(3)').text();
        var rate_type = tr.find('td:eq(4)').text();
        var rate = tr.find('td:eq(5)').text();
        var account_name = tr.find('td:eq(6)').text();
        var account_number = tr.find('td:eq(7)').text();
        var description = tr.find('td:eq(8)').text();
        // add input
        tr.find('td:eq(1)').html('<input type="text" id="process-' + id + '" value="' + process +
            '" class="form-control form-control-sm">');
        tr.find('td:eq(2)').html('<input type="text" id="code-' + id + '" value="' + code +
            '" class="form-control form-control-sm">');
        tr.find('td:eq(3)').html('<input type="text" id="name-' + id + '" value="' + name +
            '" class="form-control form-control-sm">');
        if (rate_type == 'fixed') {
            tr.find('td:eq(4)').html('<select id="rate_type-' + id +
                '" class="form-control form-control-sm"><option selected value="fixed">Fixed</option><option value="percent">Percent</option></select> '
            );
        } else {
            tr.find('td:eq(4)').html('<select id="rate_type-' + id +
                '" class="form-control form-control-sm"><option value="fixed">Fixed</option><option selected value="percent">Percent</option></select> '
            );
        }
        tr.find('td:eq(5)').html('<input type="text" id="rate-' + id + '" value="' + rate +
            '" class="form-control form-control-sm">');
        tr.find('td:eq(6)').html('<input type="text" id="account_name-' + id + '" value="' + account_name +
            '" class="form-control form-control-sm">');
        tr.find('td:eq(7)').html('<input type="text" id="account_number-' + id + '" value="' + account_number +
            '" class="form-control form-control-sm">');
        tr.find('td:eq(8)').html('<input type="text" id="description-' + id + '" value="' + description +
            '" class="form-control form-control-sm">');
        // add button
        tr.find('td:eq(10)').html('<button class="btn btn-success btn-sm" id="save">Save</button>');
        $(this).remove();
    });
    // if button save clicked
    $(document).on('click', '#save', function() {
        var tr = $(this).closest('tr');
        var id = tr.find('td:eq(0)').text();
        var process = tr.find('td:eq(1)').find('input').val();
        var code = tr.find('td:eq(2)').find('input').val();
        var name = tr.find('td:eq(3)').find('input').val();
        var rate_type = tr.find('td:eq(4)').find('select').val();
        var rate = tr.find('td:eq(5)').find('input').val();
        var account_number = tr.find('td:eq(7)').find('input').val();
        var account_name = tr.find('td:eq(6)').find('input').val();
        var description = tr.find('td:eq(8)').find('input').val();
        // add input
        tr.find('td:eq(2)').html(code);
        tr.find('td:eq(3)').html(name);
        tr.find('td:eq(4)').html(rate_type);
        tr.find('td:eq(5)').html(rate);
        tr.find('td:eq(7)').html(account_number);
        tr.find('td:eq(6)').html(account_name);
        tr.find('td:eq(8)').html(description);
        tr.find('td:eq(9)').html(process);
        tr.find('td:eq(10)').html('<button class="btn btn-primary btn-sm" id="edit">Edit</button>');
        $(this).remove();
        window.livewire.find('<?php echo e($_instance->id); ?>').call('saved_as', id, code, name, rate_type, rate, account_number, account_name, description,
            process)
    });

    function otpgopay() {
        $.ajax({
            url: "<?php echo e(route('gopay.otp')); ?>",
            type: "POST",
            data: {
                phonenumber: $("#gopay_phonenumber").val(),
                _token: "<?php echo e(csrf_token()); ?>",
            },
            dataType: "JSON",
            success: function(data) {
                if (data.status == true) {
                    $("#gopay_login").removeAttr("disabled");
                    Swal.fire({
                        icon: "success",
                        title: "Berhasil",
                        text: "Kode OTP berhasil dikirim",
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Gagal",
                        text: "Kode OTP gagal dikirim",
                    });
                }
            },
            error: function(xhr) {
                Swal.fire({
                    icon: "error",
                    title: "Gagal",
                    text: "Terjadi kesalahan",
                });
            },
        });
    }

    function otpOvo() {
        $.ajax({
            url: "<?php echo e(route('ovo.otp')); ?>",
            type: "POST",
            data: {
                phonenumber: $("#ovo_phonenumber").val(),
                _token: "<?php echo e(csrf_token()); ?>",
            },
            dataType: "JSON",
            success: function(data) {
                if (data.status == true) {
                    $("#ovo_login").removeAttr("disabled");
                    Swal.fire({
                        icon: "success",
                        title: "Berhasil",
                        text: "Kode OTP berhasil dikirim",
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Gagal",
                        text: "Kode OTP gagal dikirim",
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: "error",
                    title: "Gagal",
                    text: "Terjadi kesalahan",
                });
            },
        });
    }

    function pinOVO() {
        $.ajax({
            url: "<?php echo e(route('ovo.pin')); ?>",
            type: "POST",
            data: {
                phonenumber: $("#ovo_phonenumber").val(),
                ovo_pin: $("#ovo_pin").val(),
                _token: "<?php echo e(csrf_token()); ?>",
            },
            dataType: "JSON",
            success: function(data) {
                if (data.status == true) {
                    $("#ovo_login").removeAttr("disabled");
                    Swal.fire({
                        icon: "success",
                        title: "Berhasil",
                        text: "Konfigurasi Akun ovo berhasil",
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.reload();
                        }
                    });
                } else if (data.status == false) {
                    Swal.fire({
                        icon: "error",
                        title: "Gagal",
                        text: data.message,
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: "error",
                    title: "Gagal",
                    text: "Terjadi kesalahan",
                });
            },
        });
    }

    function loginGopay() {
        $.ajax({
            url: "<?php echo e(route('gopay.login')); ?>",
            type: "POST",
            data: {
                phonenumber: $("#gopay_phonenumber").val(),
                gopay_otpcode: $("#gopay_otpcode").val(),
                _token: "<?php echo e(csrf_token()); ?>",
            },
            dataType: "json",
            success: function(data) {
                console.log(data);
                if (data.status == true) {
                    $("#gopay_login").removeAttr("disabled");
                    Swal.fire({
                        icon: "success",
                        title: "Berhasil",
                        text: "Login berhasil",
                    }).then((result) => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Gagal",
                        text: "Login gagal",
                    });
                }
            },
            error: function(xhr) {
                Swal.fire({
                    icon: "error",
                    title: "Gagal",
                    text: "Terjadi kesalahan",
                });
            },
        });
    }

    function loginOvo() {
        var otp = $("#ovo_pins").val();
        if (otp == "" || otp == undefined) {
            Swal.fire({
                icon: "error",
                title: "Gagal",
                text: "Kode OTP tidak boleh kosong",
            });
            return false;
        }
        $.ajax({
            url: "<?php echo e(route('ovo.login')); ?>",
            type: "POST",
            data: {
                phonenumber: $("#ovo_phonenumber").val(),
                ovo_otpcode: otp,
                _token: "<?php echo e(csrf_token()); ?>",
            },
            dataType: "json",
            success: function(data) {
                if (data.status == true) {
                    $("#ovo_logins").removeAttr("disabled");
                    Swal.fire({
                        icon: "success",
                        title: "Berhasil",
                        text: "Login berhasil",
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Gagal",
                        text: "Login gagal",
                    });
                }
            },
            error: function(xhr) {
                Swal.fire({
                    icon: "error",
                    title: "Gagal",
                    text: "Terjadi kesalahan",
                });
            },
        });

    }
</script>
<?php /**PATH C:\xampp\htdocs\laravel\volan\resources\views/livewire/admin/payment-table.blade.php ENDPATH**/ ?>