<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.history-table', [])->html();
} elseif ($_instance->childHasBeenRendered('tvaeZ1J')) {
    $componentId = $_instance->getRenderedChildComponentId('tvaeZ1J');
    $componentTag = $_instance->getRenderedChildComponentTagName('tvaeZ1J');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tvaeZ1J');
} else {
    $response = \Livewire\Livewire::mount('admin.history-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('tvaeZ1J', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starsos1/laravel/resources/views/admin/pesanan.blade.php ENDPATH**/ ?>