
<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.user-table', [])->html();
} elseif ($_instance->childHasBeenRendered('rTDbNHl')) {
    $componentId = $_instance->getRenderedChildComponentId('rTDbNHl');
    $componentTag = $_instance->getRenderedChildComponentTagName('rTDbNHl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rTDbNHl');
} else {
    $response = \Livewire\Livewire::mount('admin.user-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('rTDbNHl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\smm\resources\views/admin/users.blade.php ENDPATH**/ ?>