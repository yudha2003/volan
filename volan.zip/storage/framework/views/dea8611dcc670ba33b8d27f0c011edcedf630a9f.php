<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<?php echo \Livewire\Livewire::styles(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('balance-table', [])->html();
} elseif ($_instance->childHasBeenRendered('47RPdup')) {
    $componentId = $_instance->getRenderedChildComponentId('47RPdup');
    $componentTag = $_instance->getRenderedChildComponentTagName('47RPdup');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('47RPdup');
} else {
    $response = \Livewire\Livewire::mount('balance-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('47RPdup', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starsos1/laravel/resources/views/user/log-balance.blade.php ENDPATH**/ ?>