@extends('templates.main')
@section('content')
    @livewireStyles
    @livewire('order.massal-general')
    @livewireScripts
@endsection
