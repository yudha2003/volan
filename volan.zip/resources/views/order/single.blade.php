@extends('templates.main')
@section('content')
    @livewireStyles
    @livewire('order.single-general')
    @livewireScripts
@endsection
