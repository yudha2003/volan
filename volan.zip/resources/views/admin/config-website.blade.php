@extends('templates.admin')
@section('content')
    @livewireStyles
    @livewire('config-website')
    @livewireScripts
@endsection
