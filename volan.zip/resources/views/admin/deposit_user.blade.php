@extends('templates.admin')
@section('content')
    @livewireStyles
    @livewire('admin.deposit-table')
    @livewireScripts
@endsection
